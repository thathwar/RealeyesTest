﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EXCHNG.ExchngWebApp.Models
{
    public class Rate
    {
        public decimal Value { get; set; }

        public string Currency { get; set; }    
    }
}