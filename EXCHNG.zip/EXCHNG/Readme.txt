* IDE: Visual Studio 2013
* .Net framework: 4.5
* Languages: C#, Javascript
* Solution Pattern: Asp.net MVC
* Client Side Pattern: MVVM using Knockout JS
* Front end framework: Boostrap framework
* Graphs: Rickshaw graphs
* All calculation and data querying from server has been done using Jquery AJAX calls.